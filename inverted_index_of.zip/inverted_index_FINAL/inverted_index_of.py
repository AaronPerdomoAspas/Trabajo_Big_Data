from nltk.corpus import stopwords

def open_document(document):
    file = open(document)
    read = file.read()
    return read

def delete_punc_split(text):
    word_list = []
    line = 1
    punc = '''!()-[]{};:'"\, <>./?@#$%^=&*_~'''
    for ele in text:
        if ele in punc:
            text = text.replace(ele, " ")

    linea_text = text.strip().split('\n')

    for linea in linea_text:
        for word in linea.split():
            word_list.append((line, word));
        line += 1
    return word_list

def normalize_words(words):
    normalized_words = []
    for line, word in words:
        normalized = word.lower()
        normalized_words.append((line, normalized))
    return normalized_words

def delete_stopwords(words):
    word_list = []
    stop = set(stopwords.words('english'))
    for line, word in words:
        if word in stop:
            continue
        word_list.append((line, word))
    return word_list

def clean_text(text):

    words = delete_punc_split(text)
    words = normalize_words(words)
    words = delete_stopwords(words)
    return words

def inverted_index_of(text):
    inverted = {}

    for line, word in clean_text(text):
        locations = inverted.setdefault(word, [])
        locations.append(line)

    return inverted

def inverted_index_add(inverted, doc_id, doc_index):

    for word, locations in doc_index.items():
        indices = inverted.setdefault(word, {})
        indices[doc_id] = locations
    return inverted