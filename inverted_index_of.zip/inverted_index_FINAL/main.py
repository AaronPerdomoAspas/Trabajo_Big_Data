from time import *

from inverted_index_of import open_document, inverted_index_of, inverted_index_add

if __name__ == '__main__':
    documents = {'doc1': 'C:/Users/andre/Desktop/Andre Uni/Tercero/BD/prueba1.txt',
                 'doc2': 'C:/Users/andre/Desktop/Andre Uni/Tercero/BD/prueba2.txt',
                 'doc3': 'C:/Users/andre/Desktop/Andre Uni/Tercero/BD/prueba3.txt',
                 'doc4': 'C:/Users/andre/Desktop/Andre Uni/Tercero/BD/prueba4.txt',
                 'doc5': 'C:/Users/andre/Desktop/Andre Uni/Tercero/BD/prueba5.txt',
                 'doc6': 'C:/Users/andre/Desktop/Andre Uni/Tercero/BD/prueba6.txt',
                 'doc7': 'C:/Users/andre/Desktop/Andre Uni/Tercero/BD/prueba7.txt',
                 'doc8': 'C:/Users/andre/Desktop/Andre Uni/Tercero/BD/prueba8.txt',
                 'doc9': 'C:/Users/andre/Desktop/Andre Uni/Tercero/BD/prueba9.txt',
                 'doc10': 'C:/Users/andre/Desktop/Andre Uni/Tercero/BD/prueba10.txt'
                 }

    inverted = {}
    start = time()

    for doc_id, text in documents.items():
        i = open_document(text)
        doc_index = inverted_index_of(i)
        inverted_index_add(inverted, doc_id, doc_index)
        end = time()


    # Print Inverted-Index
    for word, doc_locations in inverted.items():
        print(word, doc_locations)

    tiempo = end - start
    print(tiempo)
